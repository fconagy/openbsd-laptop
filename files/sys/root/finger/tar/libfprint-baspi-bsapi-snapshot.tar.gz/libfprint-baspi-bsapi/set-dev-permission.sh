chmod o+w /dev/bus/usb/001/003
usermod -a -G plugdev fabrice
