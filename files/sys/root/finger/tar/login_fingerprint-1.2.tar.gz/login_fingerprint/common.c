#include <sys/types.h>

#include <stdio.h>

#include <fprint.h>

struct
fp_dscv_dev *discover_device(struct fp_dscv_dev **discovered_devs)
{
	struct fp_dscv_dev *ddev = discovered_devs[0];
	struct fp_driver *drv;
	if (!ddev)
		return (NULL);

	drv = fp_dscv_dev_get_driver(ddev);
	return ddev;
}
